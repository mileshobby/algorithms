# Implement a queue with #enqueue and #dequeue, as well as a #max API,
# a method which returns the maximum element still in the queue. This
# is trivial to do by spending O(n) time upon dequeuing.
# Can you do it in O(1) amortized? Maybe use an auxiliary storage structure?

# Use your RingBuffer to achieve optimal shifts! Write any additional
# methods you need.

require_relative 'ring_buffer'

class QueueWithMax
  attr_accessor :store

  def initialize
    @store = RingBuffer.new
    @max_queue = RingBuffer.new
  end

  def enqueue(val)
    @store.push(val)
    if @max_queue.length == 0
      @max_queue.push(val)
    elsif val > @max_queue[@max_queue.length-1]
      @max_queue.push(val)
    else
      @max_queue.push(@max_queue[@max_queue.length-1])
    end
  end

  def dequeue
    if @max_queue.shift == @store.shift
      recalc_maxes
    end
  end

  def max
    @max_queue[@max_queue.length-1]
  end

  def length
    @store.length
  end

  def recalc_maxes
    new_maxes = RingBuffer.new
    (0..store.length - 1).each do |i|
      val = @store[i]
      if new_maxes.length == 0
        new_maxes.push(val)
      elsif val > new_maxes[new_maxes.length - 1]
        new_maxes.push(val)
      else
        new_maxes.push(new_maxes[new_maxes.length - 1])
      end
    end
    @max_queue = new_maxes
  end
  
end
